//humburger button
const hamburgerMenu = document.querySelector(".hamburger-menu");
const menuNav = document.querySelector(".menu-nav");

hamburgerMenu.addEventListener("click", () => {
    menuNav.classList.toggle("show");
});


//typing animation
var typed = new Typed('#text', {
    strings: ['Front-End Developer', 'Blockchind Development '],
    typeSpeed: 100,
    backSpeed: 120,
    backDelay: 800,
    loop: true,
});